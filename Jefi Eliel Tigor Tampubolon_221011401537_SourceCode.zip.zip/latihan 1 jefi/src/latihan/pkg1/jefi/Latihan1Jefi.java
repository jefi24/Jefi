package latihan.pkg1.jefi;

public class Latihan1Jefi {

    
    public static void main(String[] args) {
        System.out.println("Hello,Dunia");
        System.out.println("Nama                    : Jefi Eliel Tigor Tampubolon");
        System.out.println("Nim                     : 221011401537");
        System.out.println("Alasan Pilih Jurusan IT : mau coba yang lebih berbeda");
    }
    
}
