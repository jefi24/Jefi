package latihan.pkg1.jefi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Latihan_GUI2 {

    public static void main(String[] args) {
        // Create frame for the window
        JFrame frame = new JFrame("Input Nilai Mahasiswa");
        frame.setSize(600, 320);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Create labels and text fields
        JLabel lblNim = new JLabel("NIM:");
        lblNim.setBounds(20, 20, 80, 25);
        frame.add(lblNim);

        JTextField tfNim = new JTextField();
        tfNim.setBounds(120, 20, 200, 25);
        frame.add(tfNim);

        JLabel lblNama = new JLabel("Nama:");
        lblNama.setBounds(20, 50, 80, 25);
        frame.add(lblNama);

        JTextField tfNama = new JTextField();
        tfNama.setBounds(120, 50, 200, 25);
        frame.add(tfNama);

        JLabel lblUts = new JLabel("Nilai UTS:");
        lblUts.setBounds(20, 80, 80, 25);
        frame.add(lblUts);

        JTextField tfUts = new JTextField();
        tfUts.setBounds(120, 80, 200, 25);
        frame.add(tfUts);

        JLabel lblUas = new JLabel("Nilai UAS:");
        lblUas.setBounds(20, 110, 80, 25);
        frame.add(lblUas);

        JTextField tfUas = new JTextField();
        tfUas.setBounds(120, 110, 200, 25);
        frame.add(tfUas);

        JButton btnCalculate = new JButton("Hitung");
        btnCalculate.setBounds(120, 140, 100, 30);
        frame.add(btnCalculate);

        JTextArea resultArea = new JTextArea();
        resultArea.setBounds(20, 180, 540, 80);
        resultArea.setEditable(false);
        frame.add(resultArea);

        // Action Listener
        btnCalculate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nim = tfNim.getText().trim();
                String nama = tfNama.getText().trim();
                String utsText = tfUts.getText().trim();
                String uasText = tfUas.getText().trim();

                // Validasi input kosong
                if (nim.isEmpty() || nama.isEmpty() || utsText.isEmpty() || uasText.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Semua field harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                try {
                    double uts = Double.parseDouble(utsText);
                    double uas = Double.parseDouble(uasText);
                    double rata = (uts + uas) / 2;

                    String grade;
                    if (rata < 50) grade = "E";
                    else if (rata < 60) grade = "D";
                    else if (rata < 70) grade = "C";
                    else if (rata < 80) grade = "B";
                    else grade = "A";

                    // Display results using formatted output
                    resultArea.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
                    
                    resultArea.setText(
    "====================================================================\n" +
    String.format("%-15s %-10s %-10s %-10s %-12s %-6s\n", "NIM", "Nama", "UTS", "UAS", "Rata-rata", "Grade") +
    "====================================================================\n" +
    String.format("%-15s %-10s %-10.2f %-10.2f %-12.2f %-6s\n", nim, nama, uts, uas, rata, grade)
);


                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Nilai UTS dan UAS harus berupa angka!", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.setVisible(true);
    }
}
